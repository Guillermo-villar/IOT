import datetime
import math
import threading
import socket
import json
import os
import subprocess
import time

class GNSSSimluator:
    def __init__(self):
        self.HOST = self.get_host_name()  
        self.PORT = int(os.getenv("PORT"))
        self.UC_SIMULATOR_HOST = os.getenv("UC_SIMULATOR_HOST")
        self.UC_SIMULATOR_PORT = int(os.getenv("UC_SIMULATOR_PORT"))
        self.simulation_inputs = []
        self.frequency = 1

    def get_host_name(self):
        bashCommandName = 'echo $HOSTNAME'
        host = subprocess.check_output(['bash','-c', bashCommandName]) \
                .decode("utf-8")[0:-1]
        return host
    
    def receive_simulation_inputs(self):
        """Recepción de mensajes procedentes del generador de rutas."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((self.HOST, self.PORT))
            s.listen()
            conn, addr = s.accept()
            with conn:
                print(f"Connected by {addr}")
                while True:
                    data = conn.recv(1024)
                    if not data:
                        break
                    else:
                        data = data.decode("utf-8")
                        # print("{} - He recibido el mensaje:{}".format(datetime.datetime.now(), data))
                        self.simulation_inputs.append(json.loads(data))
                        conn.sendall(bytes("ok-" + str(time.time()), "utf-8"))

    def simulate_positioning(self):
        """Generación de valores aleatorios de posición a partir de los datos de 
        referencia obtenidos del generador de rutas."""
        print("He comenzado a simular la posición")
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            print("Conectando a {}:{}".format(self.UC_SIMULATOR_HOST, self.UC_SIMULATOR_PORT))
            
            s.connect((self.UC_SIMULATOR_HOST, self.UC_SIMULATOR_PORT))
            while True: 
                for position in self.simulation_inputs:
                    times = math.trunc(position["Time"] / self.frequency) + 1
                    while times - 1 > 0:
                        simulated_position = {"Type": "GPS", "Position":
                        position["Origin"], "Speed": position["Speed"],
                        "Timestamp":
                        datetime.datetime.timestamp(datetime.datetime.now())*1000}
                        s.sendall(bytes(json.dumps(simulated_position), "utf-8"))
                        print("{} - He enviado el mensaje:{}".format(datetime.datetime.now(), simulated_position))
                        print("{} - Volveré a enviar mensaje en: {} segundos".format(datetime.datetime.now(), self.frequency))
                        data = s.recv(1024)
                        self.check_update_frequency(data)
                        time.sleep(self.frequency)
                        times -= 1
                    last_position = position["Destination"]
                    simulated_position = {"Type": "GPS", 
                                          "Position": last_position, 
                                          "Speed": position["Speed"], 
                                          "Timestamp": datetime.datetime.timestamp(datetime.datetime.now())*1000}
                    s.sendall(bytes(json.dumps(simulated_position), "utf-8"))
                    data = s.recv(1024)
                    print("{} - He enviado el mensaje:{}".format(datetime.datetime.now(), simulated_position))
                    self.check_update_frequency(data)
                    print("{} - Volveré a enviar mensaje en: {}segundos".format(datetime.datetime.now(), self.frequency))
                    time.sleep(self.frequency)

    def check_update_frequency(self, data):
        if data:
            data = data.decode("utf-8")
            try:
                data = json.loads(data)
                frequency = data.get("updated_frequency")
                if frequency:
                    self.frequency = data.get("updated_frequency")
                    print("nueva frequencia rcv: {}".format(self.frequency))
            except json.JSONDecodeError:
                pass
        time.sleep(self.frequency)

if __name__ == '__main__':
    try:
        gnss_simulator = GNSSSimluator()
        t1 = threading.Thread(target=gnss_simulator.receive_simulation_inputs, daemon=True)
        t1.start()
        t2 = threading.Thread(target=gnss_simulator.simulate_positioning, daemon=True)
        t2.start()
        t1.join()
        t2.join()
    except Exception as e:
        print(e)