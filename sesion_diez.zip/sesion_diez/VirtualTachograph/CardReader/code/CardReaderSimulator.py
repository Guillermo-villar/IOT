import datetime
import json
import math
import os
import random
import socket
import time

def simulate_current_driver():
    is_driver = 0
    driver_present = 0
    UC_SIMULATOR_HOST = os.getenv("UC_SIMULATOR_HOST")  # session01 Positioning System Simulator
    UC_SIMULATOR_PORT = int(os.getenv("UC_SIMULATOR_PORT"))

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((UC_SIMULATOR_HOST, UC_SIMULATOR_PORT))
        while True:
            is_driver = math.trunc(random.uniform(0.5, 1.5))
            if is_driver == 1:
                driver_present = math.trunc(random.uniform(1.5, 3.5))
                simulated_driver = {"Type": "CardReader", "is driver": is_driver, "driver_present": "Driver " + 
                                    str(driver_present), "Timestamp": 
                                    datetime.datetime.timestamp(datetime.datetime.now()) * 1000}
            else:
                simulated_driver = {"Type": "CardReader", "is driver": is_driver, "driver_present": "None", 
                                    "Timestamp": 
                                    datetime.datetime.timestamp(datetime.datetime.now()) * 1000}
            s.sendall(bytes(json.dumps(simulated_driver), "utf-8"))
            print("{} He enviado el mensaje: {}".format(datetime.datetime.now(), simulated_driver))
            data = s.recv(1024)
            frequency = random.uniform(0.0, 60.0)
            print("{} Volveré a enviar mensaje en: {}".format(datetime.datetime.now(), frequency))
            time.sleep(frequency)

if __name__ == '__main__':
    try:
        simulate_current_driver()
    except Exception as e:
        print(e)