import datetime
import json
import math
import os
import random
import socket
import subprocess
import threading
import time

class Odometer():
    def __init__(self):
        self.UC_SIMULATOR_HOST = os.getenv("UC_SIMULATOR_HOST") 
        self.UC_SIMULATOR_PORT = int(os.getenv("UC_SIMULATOR_PORT"))
        self.speed_inputs = []
        self.frequency = 1 

    def get_host_name(self):
        bashCommandName = 'echo $HOSTNAME'
        host = subprocess.check_output(['bash','-c', bashCommandName]) \
                   .decode("utf-8")[0:-1]
        return host

    def receive_speed_inputs(self):
        HOST = self.get_host_name()
        PORT = int(os.getenv("PORT"))

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((HOST, PORT))
            s.listen()
            conn, addr = s.accept()
            with conn:
                print(f"Connected by {addr}")
                while True:
                    data = conn.recv(1024)
                    if not data:
                        break
                    else:
                        data = data.decode("utf-8")
                        # print("{} He recibido el mensaje: {}".format(datetime.datetime.now(), data))
                        self.speed_inputs.append(json.loads(data))
                        conn.sendall(bytes("ok-" + str(time.time()), "utf-8"))

    def simulate_current_speed(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            print("Conectando a {}:{}".format(self.UC_SIMULATOR_HOST, self.UC_SIMULATOR_PORT))
            s.connect((self.UC_SIMULATOR_HOST, self.UC_SIMULATOR_PORT))
            
            while True:
                for speed in self.speed_inputs:
                    times = math.trunc(speed["Time"] / self.frequency) + 1
                    while times > 0:
                        if times == math.trunc(speed["Time"] / self.frequency) + 1: 
                            random_speed = speed["Speed"] + random.uniform(-5.0, 5.0)
                        else:
                            random_speed += random.uniform(-5.0, 5.0)
                        simulated_speed = {"Type": "odometer", "Speed": random_speed, "Timestamp": datetime.datetime.timestamp(datetime.datetime.now()) * 1000}
                        s.sendall(bytes(json.dumps(simulated_speed), "utf-8"))
                        print("{} - He enviado el mensaje: {}".format(datetime.datetime.now(), simulated_speed))
                        data = s.recv(1024)
                        print("He recibido el mensaje: {}".format(data))

                        self.check_update_frequency(data)
                        times -= 1
    
    def check_update_frequency(self, data):
        if data:
            data = data.decode("utf-8")
            try:
                data = json.loads(data)
                frequency = data.get("updated_frequency")
                if frequency:
                    self.frequency = data.get("updated_frequency")
                    print("nueva frequencia rcv: {}".format(self.frequency))
            except json.JSONDecodeError:
                pass
        time.sleep(self.frequency)
        

if __name__ == '__main__':
    odometer = Odometer()
    try:
        t1 = threading.Thread(target=odometer.receive_speed_inputs, daemon=True)
        t1.start()
        t2 = threading.Thread(target=odometer.simulate_current_speed, daemon=True)
        t2.start()
        t1.join()
        t2.join()

    except Exception as e:
        print(e)
