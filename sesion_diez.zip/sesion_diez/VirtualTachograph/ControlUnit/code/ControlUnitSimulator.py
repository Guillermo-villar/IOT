import datetime
import json
import os
import signal
import subprocess
import sys
import threading
import socket
import time
import paho.mqtt.client as mqtt
import random

class ControlUnit:
    def __init__(self):
        self.number_telemetries_sent = 0
        self.connection_granted = False
        self.disconnected = False
        self.tachograph_id = None
        self.monitor = Monitor()
        self.HOST = self.get_host_name()
        self.PORT = int(os.getenv("PORT")) 
        self.last_time = None
        self.current_state = {}
        self.logs = []
        self.state_changed = False
        self.sensors_publication_frequency = 1
        self.sensors_frequency_update_event = threading.Event()
        self.telemetry_publication_frequency = 5

    def get_host_name(self):
        bashCommandName = 'echo $HOSTNAME'
        host = subprocess.check_output(['bash','-c', bashCommandName]) \
                .decode("utf-8")[0:-1]
        return host

    def client_listener(self, connection, address):
        print("{} - New connection {} "
            "{}".format(datetime.datetime.now(), connection, address))
        while not monitor.kill_now:
            data = connection.recv(1024)
            if data:
                data = data.decode("utf-8")
                # print("{} - He recibido el mensaje: "
                #     "{}".format(datetime.datetime.now(), data))
            self.process_received_message(data)
            connection.sendall(bytes("ok-" + str(time.time()),
                                        "utf-8"))
            # si se actualiza la var sensors_publication_frequency
            if self.sensors_frequency_update_event.is_set(): 
                self.update_sensors_sampling_frequency(connection, address)
                self.sensors_frequency_update_event.clear()

    def process_received_message(self, data):
        data = json.loads(data)
        if data["Type"] == "GPS":
            self.current_state["Position"] = data["Position"]
            self.current_state["GPSSpeed"] = data["Speed"]

        else:
            if data["Type"] == "odometer":
                self.current_state["Speed"] = data["Speed"]
            else:
                if data["Type"] == "CardReader":
                    self.current_state["driver_present"] = data["driver_present"]
        self.current_state["Timestamp"] = data["Timestamp"]
        self.logs.append(self.current_state)

    def data_logger(self):
        while not monitor.kill_now:
            if "driver_present" in self.current_state and \
                "Speed" in self.current_state and \
                "GPSSpeed" in self.current_state and \
                "Timestamp" in self.current_state:  
                last_time = 0
                if self.current_state["Timestamp"] > last_time:
                    if self.current_state["driver_present"] == "None" and self.current_state["Speed"] > 0.0:
                        self.state_changed = True
                        print("verde")
                        #generate_movement_without_driver_warning()
                    if self.current_state["Speed"] > 80.0:
                        print("rojo")
                        self.state_changed = True
                        #generate_overspeed_warning()
                    if self.current_state["Speed"] - self.current_state["GPSSpeed"] > 3.0:
                        print("amarillo")
                        self.state_changed = True
                        #generate_speed_incoherence_warning()
                    last_time = datetime.datetime.timestamp(datetime.datetime.now()) * 1000
                time.sleep(1)

    def mqtt_communications(self):
        client.username_pw_set(username="fic_server",
                               password="fic_password")
        client.on_connect = self.on_connect
        client.on_message = self.on_message

        self.tachograph_id = "tachograph_control_unit-" + str(random.randint(1, 5))

        SESSION_TOPIC = "/fic/tachographs/" + self.get_host_name() + "/session/"
        connection_dict = {"Tachograph_id": self.tachograph_id,
                           "Status": "Off - Unregulate Disconnection",
                           "Timestamp": datetime.datetime.timestamp(datetime.datetime.now()) * 1000}
        connection_str = json.dumps(connection_dict)
        client.will_set(SESSION_TOPIC, connection_str)

        MQTT_SERVER = os.getenv("MQTT_SERVER_ADDRESS")
        MQTT_PORT = int(os.getenv("MQTT_SERVER_PORT"))
        client.connect(MQTT_SERVER, MQTT_PORT, 60)
        client.loop_start()

        while not self.disconnected and not monitor.kill_now:
            # print("checkeando si connection_granted: ", self.connection_granted)
            if self.connection_granted:
                self.publish_telemetry(client)
                #self.publish_events(client)
            else:
                time.sleep(self.telemetry_publication_frequency)
        client.loop_stop()

    def publish_telemetry(self, client):
        STATE_TOPIC = "/fic/tachographs/" + self.get_host_name() + "/telemetry/"

        while self.number_telemetries_sent < len(self.logs):
            client.publish(
                STATE_TOPIC,
                payload=json.dumps(self.logs[self.number_telemetries_sent]),
                qos=1,
                retain=False
            )
            print("telemetria enviada: ", self.logs[self.number_telemetries_sent])
            self.number_telemetries_sent += 1

    def on_connect(self, client, userdata, flags, reasonCode, properties):
        rc = reasonCode
        print("on_connect - rc del broker: ", str(rc))
        if rc == 0:
            REQUEST_ACCESS_TOPIC = "/fic/tachographs/" + self.get_host_name() +"/request_access/"
            request_access_message = {"Tachograph_id": self.tachograph_id,
                                      "Timestamp": datetime.datetime.timestamp(datetime.datetime.now()) * 1000}
            # ¡¡¡Suscribirnos al topic antes de publicar porque el router publicaba en /config antes de estar suscritos!!!
            CONFIG_TOPIC = "/fic/tachographs/" + self.get_host_name() + "/config/"
            client.subscribe(CONFIG_TOPIC)
            print("Subscribed to ", CONFIG_TOPIC)
            print("tacograph_id: ", self.tachograph_id)
            client.publish(REQUEST_ACCESS_TOPIC,
                           payload=json.dumps(request_access_message), qos=1,
                           retain=False)

    def on_message(self, client, userdata, msg):
        print(f"on_message - msg recibido: {msg.payload.decode()}")
        topic = (msg.topic).split('/')
        
        json_config_received = json.loads(msg.payload.decode())

        if json_config_received["Tachograph_id"] == self.tachograph_id and \
            json_config_received["Authorization"] == "True" and \
            json_config_received["Config_item"] == None:
                self.connection_granted = True
        
        # update sensors_frequency
        elif json_config_received["Tachograph_id"] == self.tachograph_id and \
            json_config_received["Config_item"] == "sensors_frequency":
                print("sensors_frequency: ", json_config_received["Config_value"])
                self.sensors_frequency_update_event.set() 
                self.sensors_frequency = json_config_received["Config_value"]
        
        # update telemetry_frequency
        elif json_config_received["Tachograph_id"] == self.tachograph_id and \
            json_config_received["Config_item"] == "telemetry_frequency":
                print("telemetry_frequency: ", json_config_received["Config_value"])
                self.telemetry_publication_frequency = json_config_received["Config_value"]
        
        else:
            print("me desconecto/apago")
            client.disconnect()
            self.disconnected = True
            monitor.kill_now = True

    def update_sensors_sampling_frequency(self, connection, address):
        """
        Actualiza la frecuencia de muestreo de los sensores a la conexion
        que se pasa por parámetros.
        """
        
        sampling_frequency_message = {
            "updated_frequency": self.sensors_frequency
        }

        message_str = json.dumps(sampling_frequency_message)
        message_bytes = message_str.encode("utf-8")
        connection.sendall(message_bytes)

class Monitor():
    def __init__(self):
        self.kill_now = False
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

    def stop(self):
        self.kill_now = True

def signal_handler(signum, frame):
    print("Shutting down gracefully...")
    monitor.stop()


if __name__ == '__main__':
    monitor = Monitor()
    control_unit = ControlUnit()
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    try:
        t1 = threading.Thread(target=control_unit.data_logger, daemon=True)
        t1.start()
        t2 = threading.Thread(target=control_unit.mqtt_communications, daemon=True)
        t2.start()

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((control_unit.HOST, control_unit.PORT))
            print("{} - Listening on {}:{}".format(datetime.datetime.now(), control_unit.HOST, control_unit.PORT))
            s.listen(3)
            while True:
                print("{} - Waiting for connection...".format(datetime.datetime.now()))
                connection, address = s.accept()
                threading.Thread(target=control_unit.client_listener, args=(connection, address)).start()
        t1.join()
        t2.join()
    except Exception as e:
        print(e)