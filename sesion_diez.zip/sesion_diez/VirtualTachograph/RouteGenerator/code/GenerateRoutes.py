import datetime
import json
import os
import socket
import threading
import requests
from math import acos, cos, radians, sin


class RouteGenerator:
    def __init__(self):
        self.positions_to_simulate = []
        self.speeds_to_simulate = []

    def generate_route_simulations(self, origin_address="Toronto", destination_address="Montreal"):
        print("Asignando una ruta al vehículo")
        my_body = {
            "origin": {"address": origin_address},
            "destination": {"address": destination_address},
            "travelMode": "DRIVE",
            "languageCode": "es-ES",
            "units": "METRIC"
        }
        my_headers = {
            'Content-Type': 'application/json',
            'X-Goog-Api-Key': 'AIzaSyCX_EMZCaa4BOqjjQDfs8AbRKncovN2s20',
            'X-Goog-FieldMask': 'routes.duration,routes.legs'
        }
        api_url = "https://routes.googleapis.com/directions/v2:computeRoutes"
        response = requests.post(api_url, json=my_body, headers=my_headers)
        current_route = response.json()
        # print("La ruta es: {}".format(response.text))
        steps = response.json()["routes"][0]["legs"][0]["steps"]    # escogemos la primera ruta propuesta
        self.positions_to_simulate, self.speeds_to_simulate = self.generate_positions_speeds(steps)
        # print("He acabado de generar las posiciones y funciones a simular")
        return self.positions_to_simulate, self.speeds_to_simulate

    def generate_positions_speeds(self, steps: list):
        for step in steps:
            strStepDistance = step["distanceMeters"]
            strStepTime = step["staticDuration"]
            stepDistance = float(strStepDistance)
            stepTime = float(strStepTime[:-1])  # quitamos la s (segundos)
            stepSpeed = stepDistance / stepTime
            substeps = self.decode_polyline(step["polyline"]["encodedPolyline"])
            
            p_inicial = 0.0
            for index, _ in enumerate(substeps[:-1]):   # substeps[:-1] es para no IndexError con [index + 1]
                if index < len(substeps): 
                    if p_inicial == 0.0:
                        p_inicial = {"latitude": substeps[index][0], "longitude": substeps[index][1]}
                        
                    p2 = {"latitude": substeps[index + 1][0], "longitude": substeps[index + 1][1]}
                    points_distance = self.distance(p_inicial, p2) * 1000    # devuelve en km
                    if points_distance > 10: # descarta distancias < a 1m
                        subStepDuration = points_distance / stepSpeed
                        subStepSpeed = stepSpeed * 3.6
                        new_position = {"Origin": p_inicial, "Destination": p2, "Speed": subStepSpeed, "Time": subStepDuration}
                        self.positions_to_simulate.append(new_position)
                        new_speed = {"Speed": subStepSpeed, "Time": subStepDuration}
                        self.speeds_to_simulate.append(new_speed)
                        p_inicial = p2      # solo muevo la inicial si he genarado un segmento

        return self.positions_to_simulate, self.speeds_to_simulate


    def distance (self, p1, p2):
        p1Latitude = p1["latitude"]
        p1Longitude = p1["longitude"]
        p2Latitude = p2["latitude"]
        p2Longitude = p2["longitude"]
        # print("Calculando la distancia entre ({},{}) y ({},{})".format(p1["latitude"], p1["longitude"], p2["latitude"], p2["longitude"]))
        earth_radius = {"km": 6371.0087714, "mile": 3959}
        result = earth_radius["km"] * acos(
            cos(radians(p1Latitude)) * cos(radians(p2Latitude)) * cos(radians(p2Longitude) - radians(p1Longitude)) + sin(radians(p1Latitude)) * sin(radians(p2Latitude))
        )
        # print ("La distancia calculada es: {}".format(result))
        return result

    def decode_polyline (self, polyline_str):
        """Pass a Google Maps encoded polyline string; returns list of lat/lon pairs"""
        index, lat, lng = 0, 0, 0
        coordinates = []
        changes = {'latitude': 0, 'longitude': 0}
        # Coordinates have variable length when encoded, so just keep
        # track of whether we've hit the end of the string. In each
        # while loop iteration, a single coordinate is decoded.
        while index < len(polyline_str):
            # Gather lat/lon changes, store them in a dictionary to apply them later
            for unit in ['latitude', 'longitude']:
                shift, result = 0, 0
                while True:
                    byte = ord(polyline_str[index]) - 63
                    index += 1
                    result |= (byte & 0x1f) << shift
                    shift += 5
                    if not byte >= 0x20:
                        break
                if (result & 1):
                    changes[unit] = ~(result >> 1)
                else:
                    changes[unit] = (result >> 1)
            lat += changes['latitude']
            lng += changes['longitude']
            coordinates.append((lat / 100000.0, lng / 100000.0))
        return coordinates

    def send_positions_to_gps_simulator(self):
        POSITION_SIMULATOR_HOST = os.getenv("POSITION_SIMULATOR_HOST") # session01_Positioning_System_Simulator
        POSITION_SIMULATOR_PORT = int(os.getenv("POSITION_SIMULATOR_PORT"))

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((POSITION_SIMULATOR_HOST, POSITION_SIMULATOR_PORT))
            print(f"Conectado a {POSITION_SIMULATOR_HOST}:{POSITION_SIMULATOR_PORT}")
            
            for position in self.positions_to_simulate:
                s.sendall(bytes(json.dumps(position), "utf-8"))
                data = s.recv(1024)
                print (f"Received {data!r}")
                print("{} - He enviado el mensaje: {}".format(datetime.datetime.now(), json.dumps(position)))
            print("He terminado de enviar los mensajes al simulador de GPS")

    def send_speeds_to_odometer_simulator(self):
        """Envía datos de velocidad y duración al simulador de Odómetro."""
        SPEED_SIMULATOR_HOST = os.getenv("SPEED_SIMULATOR_HOST")
        SPEED_SIMULATOR_PORT = int(os.getenv("SPEED_SIMULATOR_PORT"))

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((SPEED_SIMULATOR_HOST, SPEED_SIMULATOR_PORT))
            print(f"Conectado {SPEED_SIMULATOR_HOST}:{SPEED_SIMULATOR_PORT}")

            for speed in self.speeds_to_simulate:
                s.sendall(bytes(json.dumps(speed), "utf-8"))
                data = s.recv(1024)
                print (f"Received {data!r}")
                print("{} - He enviado el mensaje: {}".format(datetime.datetime.now(), json.dumps(speed)))
            print("He terminado de enviar los mensajes al Odómetro")

if __name__ == '__main__':
    try:
        print("Generando routes...")
        route_generator = RouteGenerator()
        my_route = {"Origin": "Ayuntamiento de Leganés", "Destination": "Ayuntamiento de Getafe"}
        positions_to_simulate, speeds_to_simulate = route_generator.generate_route_simulations(my_route["Origin"], my_route["Destination"])
        t2 = threading.Thread(target=route_generator.send_positions_to_gps_simulator,
                            daemon=True)
        t2.start()
        t3 = threading.Thread(target=route_generator.send_speeds_to_odometer_simulator,
                            daemon=True)
        t3.start()
        t2.join()
        t3.join()
    except Exception as e:
        print(e)
