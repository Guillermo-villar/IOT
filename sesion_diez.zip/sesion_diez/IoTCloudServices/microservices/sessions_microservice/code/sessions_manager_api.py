from flask import Flask, request
from flask_cors import CORS
import requests
from sessions_db_manager import *

app = Flask(__name__)
CORS(app)

@app.route('/sessions/', methods=['PUT'])
def create_session():
    params = request.get_json()
    session_id = register_new_session(params)
    if session_id != "":
        return {"session_id": session_id}, 201
    else:
        return {"session_id": "", "Error":"Access not granted"}, 500

@app.route('/sessions/', methods=['POST'])
def terminate_session():
    params = request.get_json()
    session_id = register_session_disconnection(params)
    if session_id != "":
        return {"tachograph_hostname": session_id[0], "sessions":
            session_id[1]}, 201
    else:
        return {"tachograph_hostname": "", "sessions": []}, 500

@app.route('/sessions/', methods=['GET'])
def check_session():
    params = request.get_json()
    session_id = is_connected(params)
    if session_id != "":
        return {"tachograph_hostname": session_id[0], "sessions":
            session_id[1]}, 201
    else:
        return {"tachograph_hostname": "", "sessions": []}, 500


import os
HOST = os.getenv('HOST')
PORT = os.getenv('PORT')
app.run(host=HOST, port=PORT)
