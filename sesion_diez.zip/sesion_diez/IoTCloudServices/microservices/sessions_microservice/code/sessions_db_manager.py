import mysql.connector
import os
import json
from datetime import datetime
import random
import string

def connect_database():
    mydb = mysql.connector.connect(
        host=os.getenv('DBHOST'),
        user=os.getenv('DBUSER'),
        password=os.getenv('DBPASSWORD'),
        database=os.getenv('DBDATABASE'),
        collation="utf8mb4_unicode_ci",
        charset="utf8mb4")
    return mydb

def register_new_session(params):
    mydb = connect_database()
    sql = "SELECT tachograph_id, status FROM tachographs WHERE tachograph_id = %s ORDER BY tachograph_id ASC LIMIT 1;"
    with mydb.cursor() as mycursor:
        mycursor.execute(sql, (params["tachograph_id"],))
        myresult = mycursor.fetchall()

        status = 0
        tachograph_id = ""
        for recovered_entry in myresult:
            tachograph_id = recovered_entry[0]
            status = recovered_entry[1]
        mydb.commit()
    if tachograph_id == "":
        print("Ese tachograph no existe")
        return ""
    elif status == 1:
        print("Ese tacógrafo ya esta activo")
        return ""
    else:
        with mydb.cursor() as mycursor:
            timestamp = datetime.now()
            length = random.randint(10, 20)
            characters = string.ascii_letters + string.digits  # a-z, A-Z, 0-9
            random_string = ''.join(random.choices(characters, k=length))

            sql = "INSERT INTO sessions (session_id, tacograph_id, init_date, status) " \
                      "VALUES (%s, %s, %s, 1);"
            query_params = (random_string, params["tachograph_id"], timestamp)
            try:
                    mycursor.execute(sql, query_params)
                    mydb.commit()
                    print(mycursor.rowcount, "record inserted.")

                    sql = "UPDATE tachographs SET status = 1 WHERE tachograph_id = %s;"
                    mycursor.execute(sql, (params["tachograph_id"],))
                    mydb.commit()
                    print(mycursor.rowcount, "row updated.")
                    return random_string
            except:
                    print("Error inserting the device")
                    return ""

def register_session_disconnection(params):
    mydb = connect_database()
    sql = "SELECT tacograph_id, status, tachograph_hostname FROM tachographs WHERE tachograph_id = %s ORDER BY tachograph_id ASC LIMIT 1;"
    with mydb.cursor() as mycursor:
        mycursor.execute(sql, (params["tachograph_id"],))
        myresult = mycursor.fetchall()

        status = 1
        tachograph_id = ""
        for recovered_entry in myresult:
            tachograph_id = recovered_entry[0]
            status = recovered_entry[1]
        mydb.commit()
    if tachograph_id == "":
        print("Ese tachograph no existe")
        return ""
    elif status == 0:
        print("Ese tacógrafo no esta activo")
        return ""
    else:
        with mydb.cursor() as mycursor:
            timestamp = datetime.now()
            sql = "SELECT session_id FROM sessions WHERE tachograph_id = %s AND status = 1;"
            mycursor.execute(sql, params["tachograph_id"])
            for recovered_entry in myresult:
                session_id_cerrada = recovered_entry[0]
            mydb.commit()

            sql = "UPDATE sessions SET status = 0, end_date = %s WHERE tachograph_id = %s AND status = 1;"
            query_params = (timestamp, params["tachograph_id"])
            try:
                    mycursor.execute(sql, query_params)
                    mydb.commit()
                    print(mycursor.rowcount, "sesiones actualizadas")

                    sql = "UPDATE tachographs SET status = 0 WHERE tachograph_id = %s"
                    mycursor.execute(sql, (params["tachograph_id"],))
                    mydb.commit()
                    print(mycursor.rowcount, "tacografos actualizados")

                    return [recovered_entry[2], session_id_cerrada]
            except:
                    print("Error inserting the device")
                    return ""

def is_connected(params):
    mydb = connect_database()
    sql = "SELECT tachograph_hostname, session_id FROM sessions WHERE tachograph_id = %s AND status = 1;"
    with mydb.cursor() as mycursor:
        mycursor.execute(sql, (params["tachograph_id"],))
        myresult = mycursor.fetchall()

        tachograph_hostname = ""
        for recovered_entry in myresult:
            tachograph_hostname = recovered_entry[0]
            session_id = recovered_entry[1]

        mydb.commit()
    if tachograph_hostname == "":
        print("Ese tachografo no tiene sesiones abiertas")
        return ""
    else:
        return [tachograph_hostname, session_id]