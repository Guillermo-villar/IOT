from flask import Flask, request
from flask_cors import CORS
import requests

from IoTCloudServices.microservices.events_microservice.code import events_db_manager
from IoTCloudServices.microservices.telemetry_microservice.code.telemetry_db_manager import register_new_telemetry
from events_db_manager import *

app = Flask(__name__)
CORS(app)

@app.route('/event/', methods=['POST'])
def new_event():
    params = request.get_json()
    result = register_new_event(params)
    if result:
        return {"result": "Event registered"}, 201
    else:
        return {"result": "Error registering an event "}, 500

@app.route('/event/', methods=['GET'])
def check_tachograph_events():
    params = request.get_json()
    result = query_events(params)
    return result, 201

import os
HOST = os.getenv('HOST')
PORT = os.getenv('PORT')
app.run(host=HOST, port=PORT)
