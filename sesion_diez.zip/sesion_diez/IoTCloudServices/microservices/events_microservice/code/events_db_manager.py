from datetime import datetime
import mysql.connector
import os
import json

def connect_database():
    mydb = mysql.connector.connect(
        host=os.getenv('DBHOST'),
        user=os.getenv('DBUSER'),
        password=os.getenv('DBPASSWORD'),
        database=os.getenv('DBDATABASE'),
        collation="utf8mb4_unicode_ci",
        charset="utf8mb4")
    return mydb

def register_new_event(params):
    mydb = connect_database()
    sql = "SELECT tachograph_id FROM tachographs WHERE tachograph_id = %s ORDER BY tachograph_id ASC LIMIT 1;"
    with mydb.cursor() as mycursor:
        mycursor.execute(sql, (params["tachograph_id"],))
        myresult = mycursor.fetchall()

        tachograph_id = ""
        for recovered_id in myresult:
            tachograph_id = recovered_id[0]
        mydb.commit()
    if tachograph_id == "":
        print("No existe ese tachograph")
        return False
    else:
        with mydb.cursor() as mycursor:  # tachograph_hostname
            sql = "INSERT INTO events (tachograph_id, latitude, longitude, warning, Timestamp) " \
                  "VALUES (%s, %s, %s, %s, %s);"
            query_params = (params["tachograph_id"], params["position"]["Latitude"], params["position"]["Longitude"],
                            params["warning"], params["Timestamp"])
            try:
                mycursor.execute(sql, query_params)
                mydb.commit()
                print(mycursor.rowcount, "record inserted.")
                return True
            except:
                print("Error inserting the event")
                return False


def query_events(params):
    mydb = connect_database()
    sql = "SELECT * FROM events WHERE tachograph_id = %s;"
    events = []
    with mydb.cursor(dictionary=True) as mycursor:
        mycursor.execute(sql, (params["tachograph_id"],))
        myresult = mycursor.fetchall()
        for event in myresult:
            if (datetime.strptime(params["init_interval"], "%Y-%m-%d %H:%M:%S") <
                    datetime.strptime(event["Timestamp"], "%Y-%m-%d %H:%M:%S") <
                    datetime.strptime(params["end_interval"], "%Y-%m-%d %H:%M:%S")):
                events.append(event)
        mydb.commit()
    return events