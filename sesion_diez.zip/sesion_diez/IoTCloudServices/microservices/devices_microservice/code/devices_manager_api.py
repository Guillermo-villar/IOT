from flask import Flask, request
from flask_cors import CORS
import requests
from devices_db_manager import *

app = Flask(__name__)
CORS(app)

@app.route('/tachographs/', methods=['POST'])
def save_tachograph_info():
    params = request.get_json()
    tachograph_id = register_new_tachograph(params)
    if tachograph_id != "":
        return {"tachograph_id": tachograph_id}, 201
    else:
        return {"result": "error inserting a new tachograph"}, 500

@app.route('/tachographs/', methods=['GET'])
def check_all_tachographs():
    tachograph_id_list = get_active_tacographs()
    # Si la lista no está vacía
    if tachograph_id_list:
        return {tachograph_id_list}
    else:
        return {"No hay tacógrafos conectados"}

@app.route('/tachographs/params/', methods=['GET'])
def check_tachograph_info():
    params = request.get_json()
    tachograph_data = retrieve_tachograph(params)
    if tachograph_data != "":
        return {tachograph_data}, 201
    else:
        return {"result": "Error: Tachograph not found"}, 500

import os
HOST = os.getenv('HOST')
PORT = os.getenv('PORT')
app.run(host=HOST, port=PORT)
