import datetime
import mysql.connector
import os
import json

def connect_database():
    mydb = mysql.connector.connect(
        host=os.getenv('DBHOST'),
        user=os.getenv('DBUSER'),
        password=os.getenv('DBPASSWORD'),
        database=os.getenv('DBDATABASE'),
        collation="utf8mb4_unicode_ci",
        charset="utf8mb4")
    return mydb

def register_new_tachograph(params):
    mydb = connect_database()
    sql = "SELECT tachograph_id FROM tachographs WHERE tachograph_id = %s ORDER BY tachograph_id ASC LIMIT 1;"
    with mydb.cursor() as mycursor:
        mycursor.execute(sql, (params["tachograph_id"],))
        myresult = mycursor.fetchall()

        tachograph_id = ""
        for recovered_id in myresult:
            tachograph_id = recovered_id[0]
        mydb.commit()
    if tachograph_id != "":
        print("Ya hay un tacógrafo con mi mismo id")
        return ""
    else:
        sql = "SELECT logic_id FROM available_ids WHERE is_assigned = 0 AND logic_id < %s ORDER BY logic_id ASC LIMIT 1;"
        with mydb.cursor() as mycursor:
            query_params = (params["tachograph_id"],)
            mycursor.execute(sql, query_params)
            myresult = mycursor.fetchall()
            for recovered_id in myresult:
                tachograph_id = recovered_id[0]
            mydb.commit()

        print(f"Tachograph ID available: {tachograph_id}")

        if tachograph_id != "":
            with mydb.cursor() as mycursor:                            #tachograph_hostname
                sql = "INSERT INTO tachographs (tachograph_id, telemetry_rate, sensors_sampling_rate, status) " \
                      "VALUES (%s, 1, 1.0, 0);"
                query_params = (params["tachograph_id"],)
                try:
                    mycursor.execute(sql, query_params)
                    mydb.commit()
                    print(mycursor.rowcount, "record inserted.")
                    sql = "UPDATE available_ids SET is_assigned = 1 WHERE logic_id = %s;"
                    mycursor.execute(sql, (params["tachograph_id"],))
                    mydb.commit()
                    print(mycursor.rowcount, "row updated.")
                    return tachograph_id
                except:
                    print("Error inserting the device")
                    return ""

def get_active_tacographs():
    mydb = connect_database()
    sql = "SELECT tachograph_id FROM tachographs WHERE status = 1;"
    plates = []
    with mydb.cursor() as mycursor:
        mycursor.execute(sql)
        myresult = mycursor.fetchall()
        for tachograph in myresult:
            data = {"tachograph_id": tachograph}
            plates.append(data)
        mydb.commit()
    return plates

def retrieve_tachograph(params):
    mydb = connect_database()
    sql = ("SELECT tachograph_id, sensors_sampling_rate, telemetry_rate, status "
           "FROM tachographs WHERE tachograph_id = %s;")
    with mydb.cursor() as mycursor:
        mycursor.execute(sql, params["tachograph_id"])
        myresult = mycursor.fetchall()

        tachograph_id = ""
        tachograph_state = 0

        for recovered_id in myresult:
            tachograph_id = recovered_id[0]
            sensors_sampling_rate = recovered_id[1]
            telemetry_rate = recovered_id[2]
            tachograph_state = recovered_id[3]
        mydb.commit()
    if tachograph_id == "":
        print("No existe un tacografo con esta id")
        return ""
    elif tachograph_state == 0:
        print("No existe un tacografo con esta id que este activo")
        return ""

    found_tachograph =  {"tachograph_id": tachograph_id,
                        #"telemetry_hostname": tachograph_hostname,
                        "sensors_sampling_rate": sensors_sampling_rate,
                        "telemetry_rate": telemetry_rate,
                         "status": tachograph_state}
    return found_tachograph

