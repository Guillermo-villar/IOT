from flask import Flask, request
from flask_cors import CORS
import requests
from telemetry_db_manager import *

app = Flask(__name__)
CORS(app)

@app.route('/telemetry/', methods=['POST'])
def new_telemetry():
    params = request.get_json()
    result = register_new_telemetry(params)
    if result:
        return {"result": "Telemetry registered"}, 201
    else:
        return {"result": "Error registering telemetries "}, 500

@app.route('/telemetry/', methods=['GET'])
def check_tachograph_telemetries():
    params = request.get_json()
    result = query_telemetry(params)
    if not result:
        return {"result": "No telemetries found"}, 201
    return result, 201

@app.route('/telemetry/positions/', methods=['GET'])
def check_tachograph_position():
    error_message, result = retrieve_vehicles_last_position()
    if error_message == "":
        return result, 201
    else:
        return {"Error Message": error_message}, 500



import os
HOST = os.getenv('HOST')
PORT = os.getenv('PORT')
app.run(host=HOST, port=PORT)
