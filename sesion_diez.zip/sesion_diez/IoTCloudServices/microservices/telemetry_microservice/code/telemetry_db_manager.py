from datetime import datetime
import mysql.connector
import os
import json
import datetime

from h5py.h5pl import append


def connect_database():
    mydb = mysql.connector.connect(
        host=os.getenv('DBHOST'),
        user=os.getenv('DBUSER'),
        password=os.getenv('DBPASSWORD'),
        database=os.getenv('DBDATABASE'),
        collation="utf8mb4_unicode_ci",
        charset="utf8mb4")
    return mydb

def register_new_telemetry(params):
    mydb = connect_database()
    sql = "INSERT INTO telemtries (tachograph_id, latitude, longitude, GPSSpeed, Speed, Driver, time_stamp) " \
                      "VALUES (%s, %s, %s, %s, %s, %s, %s);"
    insert_params = (params["tachograph_id"], params["position"]["Latitude"], params["position"]["Longitude"],
                    params["GPSSpeed"], params["Speed"],
                    params["Driver"], params["time_stamp"]) #datetime.datetime.now()
    with mydb.cursor() as mycursor:
        try:
            mycursor.execute(sql, insert_params)
            mydb.commit()
            print(mycursor.rowcount, "telemtry inserted.")
            return True
        except:
            print("Error inserting")
            return False

def query_telemetry(params):
    mydb = connect_database()
    sql = "SELECT * FROM telemtries WHERE tachograph_id = %s;"
    query_params = (params["tachograph_id"]) #params["init_interval"]

    telemetries = []
    with mydb.cursor(dictionary=True) as mycursor:
        mycursor.execute(sql, query_params)
        myresult = mycursor.fetchall()
        for telemetry in myresult:
            if (datetime.strptime(params["init_interval"], "%Y-%m-%d %H:%M:%S") <
                datetime.strptime(telemetry["time_stamp"], "%Y-%m-%d %H:%M:%S") <
                datetime.strptime(params["end_interval"], "%Y-%m-%d %H:%M:%S")):
                    telemetries.append(myresult)
        mydb.commit()
    return telemetries

def retrieve_vehicles_last_position():
    mydb = connect_database()
    sql = """
            SELECT t1.tachograph_id, t1.latitude, t1.longitude
            FROM telemetries t1
            INNER JOIN (
                SELECT tachograph_id, MAX(time_stamp) AS latest_time
                FROM telemetries
                GROUP BY tachograph_id
            ) t2
            ON t1.tachograph_id = t2.tachograph_id AND t1.time_stamp = t2.latest_time;
        """
    with mydb.cursor as mycursor:
        try:
            mycursor.execute(sql)
            results = mycursor.fetchall()
            mydb.commit()
            return 201, results
        except:
            return "No fue posible recuperar las telemetrías", ""

