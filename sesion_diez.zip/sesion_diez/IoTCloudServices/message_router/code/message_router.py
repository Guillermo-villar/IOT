import paho.mqtt.client as mqtt
import os
import json
import datetime
import random
import time
import threading
import requests

class MessageRouter():
    def __init__(self):
        self.connected_tachographs = []
        self.authorised_tachographs = ["tachograph_control_unit-1",
                                   "tachograph_control_unit-2",
                                   "tachograph_control_unit-3",
                                   "tachograph_control_unit-4"]
        self.subscribed_topics = {}
        self.tacograph_upload_times = {}

    def on_connect(self, client, userdata, flags, reasonCode, properties):
        rc = reasonCode
        print("on_connect-msg rcv: ", str(rc)) 
        
        if rc == 0:
            INIT_TOPIC = "/fic/tachographs/+/request_access/"
            client.subscribe(INIT_TOPIC)
            print("Subscribed to ", INIT_TOPIC)

    def on_message(self, client, userdata, msg):
        print(f"on_message-msg rcv: {msg.payload.decode()}")

        topic = (msg.topic).split('/')
        hostname = topic[-3]
        if "request_access" in msg.topic:
            received_request_access = json.loads(msg.payload.decode())
            # print("received_request_access: ", received_request_access)
            
            # Caso: no autorizado
            if not self.find_authorised_tachograph(received_request_access["Tachograph_id"]):
                request_access_response = {"Tachograph_id": received_request_access["Tachograph_id"],
                                           "Authorization": "False",
                                           "Timestamp": datetime.datetime.timestamp(datetime.datetime.now()) * 1000}
                client.publish("/fic/tachographs/" + hostname + "/config/",
                               payload=json.dumps(request_access_response), qos=1,
                               retain=False)

            else:
                found, position = self.is_connected(received_request_access["Tachograph_id"])

                # Caso: already connected
                if found:
                    request_access_response = {"Tachograph_id": received_request_access["Tachograph_id"],
                                               "Authorization": "False",
                                               "Timestamp": datetime.datetime.timestamp(datetime.datetime.now()) * 1000}

                    client.publish("/fic/tachographs/" + hostname + "/config/",
                                   payload=json.dumps(request_access_response), qos=1,
                                   retain=False)
                    # print("[publico]: ", request_access_response, "en el topic: ", "/fic/tachographs/" + topic[-3] + "/config/")
                elif not found:
                    self.register_tachograph_connection(received_request_access["Tachograph_id"], hostname)
                    request_access_response = {"Tachograph_id":received_request_access["Tachograph_id"],
                                                "Authorization": "True",
                                                "Config_item": None,
                                                "Timestamp":datetime.datetime.timestamp(datetime.datetime.now()) *1000}

                    client.publish("/fic/tachographs/" + hostname + "/config/",
                                       payload=json.dumps(request_access_response), qos=1,
                                       retain=False)
                    
                    threading.Thread(target=self.update_tachograph_times, args=(received_request_access["Tachograph_id"], hostname,), daemon=True).start()

                    # print("[publico]: ", request_access_response, "en el topic: ", "/fic/tachographs/" + topic[-3] + "/config/")
                    telemetry_topic = "/fic/tachographs/" + hostname + "/telemetry/"
                    client.subscribe(telemetry_topic)
                    session_topic = "/fic/tachographs/" + hostname + "/session/"
                    client.subscribe(session_topic)
                    event_topic = "/fic/tachographs/" + hostname + "/events/"
                    client.subscribe(event_topic)
                    print("Subscribed to ", telemetry_topic, "and ", session_topic)

        if topic[-2] == "telemetry":
            telemetry_info = json.loads(msg.payload.decode())
            for tacograph in self.connected_tachographs:
                # print(f"[tacograph]: {tacograph}")
                # print(f"[telemetry_info]: {telemetry_info}")
                if tacograph["hostname"] == hostname:
                    tacograph["telemetries"].append(telemetry_info)
                    break
            print(f"Telemetry info: {telemetry_info}")

        elif topic[-2] == "events":
            event_info = json.loads(msg.payload.decode())
            for tacograph in self.connected_tachographs:
                if tacograph["hostname"] == hostname:
                    tacograph["event"].append(event_info)
                    break
            print(f"Event info: {event_info}")

        elif topic[-2] == "session":
            print("[self.connected_tachographs] - antes : ", self.connected_tachographs)
            for tacograph in self.connected_tachographs:
                print("comparando con: ", tacograph["hostname"], "y con: ", hostname)
                if tacograph["hostname"] == hostname:
                    disconnect_info = {
                        "Tachograph_id": json.loads(msg.payload.decode())["Tachograph_id"],
                        "hostname": hostname,
                        "telemetries": tacograph["telemetries"],
                        "events": tacograph["events"],
                        "Disconnection_time": datetime.datetime.timestamp(datetime.datetime.now()) *1000
                    }
                    self.connected_tachographs.remove(tacograph) 
                    break
            
            filename = f"{disconnect_info['Tachograph_id']}_{int(disconnect_info['Disconnection_time'])}.json"

            # Guardar la información en un archivo JSON
            with open(filename, 'w') as file:
                json.dump(disconnect_info, file)
            print(f"Information saved in {filename}")


    def is_connected(self, id_of_tachograph):
        for tacograph in self.connected_tachographs:
            if tacograph["Tachograph_id"] == id_of_tachograph:
                return True, tacograph["Tachograph_id"]
        if id_of_tachograph in self.connected_tachographs:
            position = self.connected_tachographs.index(id_of_tachograph)
            return True, position

        return False, None

    def find_authorised_tachograph(self, id_of_tachograph):
        if id_of_tachograph not in self.authorised_tachographs:
            print(f"Tacógrafo {id_of_tachograph}, no autorizado")
            return False
        return True

    def register_tachograph_connection(self, id_of_tachograph, hostname):
        #self.connected_tachographs.append({"Tachograph_id": id_of_tachograph , "hostname": hostname, "telemetries": [], "events": []})
        #TODO verificar esto
        session_id = ""
        data = {"tachograph_id": id_of_tachograph, "tachograph_hostname": hostname}
        print("{} - Solicitando creación de sesión para: {}".format(datetime.datetime.now(), json.dumps(data)))
        host = os.getenv('SESSIONS_MICROSERVICE_ADDRESS')
        port = os.getenv('SESSIONS_MICROSERVICE_PORT')

        r = requests.put('http://' + host + ':' + port + '/sessions/', json=data)
        if r.status_code == 201:
            print("{} - Tacógrafo conectado".format(datetime.datetime.now()))
            complete_result = r.json()
            session_id = complete_result["session_id"]

        return session_id

    def register_tachograph_disconnection(self, id_of_tachograph):
        #TODO verificar esto
        session_id = ""
        data = {"tachograph_id": id_of_tachograph}
        print("{} - Solicitando terminación de sesión para: {}".format(datetime.datetime.now(), json.dumps(data)))
        host = os.getenv('SESSIONS_MICROSERVICE_ADDRESS')
        port = os.getenv('SESSIONS_MICROSERVICE_PORT')

        r = requests.post('http://' + host + ':' + port + '/sessions/', json=data)
        if r.status_code == 201:
            print("{} - Tacógrafo desconectado".format(datetime.datetime.now()))
            complete_result = r.json()
            session_id = complete_result["session_id"]

        return session_id

    def store_telemetry(self, data):

        #print("{} - Solicitando terminación de sesión para: {}".form
        data = json.dumps(data)
        host = os.getenv('TELEMETRY_MICROSERVICE_ADDRESS')
        port = os.getenv('TELEMETRY_MICROSERVICE_PORT')

        r = requests.post('http://' + host + ':' + port + '/telemetry/', json=data)
        if r.status_code == 201:
            print("{} - Telemetría registrada".format(datetime.datetime.now()))
            complete_result = r.json()
            #d = complete_result[""]

    def store_event(self, data):

        data = json.dumps(data)
        host = os.getenv('EVENTS_MICROSERVICE_ADDRESS')
        port = os.getenv('EVENTS_MICROSERVICE_PORT')

        r = requests.post('http://' + host + ':' + port + '/event/', json=data)
        if r.status_code == 201:
            print("{} - Evento registrado".format(datetime.datetime.now()))
            complete_result = r.json()
            #d = complete_result[""]

    def update_tachograph_times(self, tachograph_id, hostname):
        while True:
            update_time = random.randint(10, 240)
            sensor_time = random.uniform(0.1, 2) # 0.1 para evitar zero division
            telemetry_time = random.uniform(5, 60)
            message_sensor_time = {"Tachograph_id": tachograph_id,
                                   "Authorization": "True",
                                   "Config_item": "sensors_frequency", 
                                   "Config_value": sensor_time, 
                                   "Timestamp": datetime.datetime.timestamp(datetime.datetime.now())*1000}
            message_telemetry_time = {"Tachograph_id": tachograph_id,
                                      "Authorization": "True",
                                      "Config_item": "telemetry_frequency", 
                                      "Config_value": telemetry_time, 
                                      "Timestamp": datetime.datetime.timestamp(datetime.datetime.now())*1000}
            topic = "/fic/tachographs/" + hostname + "/config/"

            print("new sensor time: ", message_sensor_time)
            print("new telemetry time: ", message_telemetry_time) 
            print("topic: ", topic) 
            client.publish(topic, payload=json.dumps(message_sensor_time), qos=1, retain=False)
            client.publish(topic, payload=json.dumps(message_telemetry_time), qos=1, retain=False)
            print("volvere a enviar en: ", update_time, "segundos") 
            time.sleep(update_time)

if __name__ == '__main__':
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    enrutador = MessageRouter()

    client.username_pw_set(username="fic_server",
                           password="fic_password")

    client.on_connect = enrutador.on_connect
    client.on_message = enrutador.on_message

    MQTT_SERVER = os.getenv("MQTT_SERVER_ADDRESS")
    MQTT_PORT = int(os.getenv("MQTT_SERVER_PORT"))
    client.connect(MQTT_SERVER, MQTT_PORT, 60)

    client.loop_forever()
